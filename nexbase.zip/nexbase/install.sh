apt update && apt upgrade -y
apt install nodejs git libvips python3 clang make -y
npm install --production --legacy-peer-deps
npm start
