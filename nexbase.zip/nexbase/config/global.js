const fs = require("fs");

global.name = "亥 Nexbase";
global.number = "";
global.dev = process.env.NODE_ENV === "development";
global.locale = "id-ID";
global.timezone = "Asia/Jakarta";
global.commandPath = "./cmds";
global.creds = "./sezz/creds";
global.store = "./sezz/store.json";
global.prefix = ".";
global.splitArgs = "|";

global.owner = {
  name: "Nexstore",
  number: ["6285179845835", "6285174174657"],
  socialMedia: [
    {
      name: "Instagram",
      url: "https://youtube.com/@Nexstoreidn",
    },
  ],
};
global.mess = {
  dev: "Perintah ini masih dalam tahap development",
  onlyOwner: "Perintah ini hanya bisa digunakan oleh owner",
};

global.setting = JSON.parse(fs.readFileSync("./config/setting.json"));

global.db = {
  users: JSON.parse(fs.readFileSync("./db/users.json")),
  groups: JSON.parse(fs.readFileSync("./db/groups.json")),
};

global.save = (name, json) =>
  new Promise((resolve) => {
    switch (name.toLowerCase()) {
      case "setting":
        fs.writeFileSync("./config/setting.json", JSON.stringify(json));
        break;
      case "users":
        fs.writeFileSync("./db/users.json", JSON.stringify(json));
        break;
      case "groups":
        fs.writeFileSync("./db/groups.json", JSON.stringify(json));
        break;
    }
    resolve(json);
  });
