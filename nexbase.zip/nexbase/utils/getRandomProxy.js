const fs = require("fs");
const path = require("path");
const getRandomInt = require("./getRandomInt");

module.exports = (protocol) => {
  const dataProxy = JSON.parse(
    fs.readFileSync(path.join(__dirname, "../db/proxy.json"))
  );
  const proxy = dataProxy.filter((val) => val.protocol === protocol);
  const index = getRandomInt(proxy.length);
  return proxy[index];
};
