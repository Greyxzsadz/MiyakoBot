/***
 * autoRead: AUTO READ MESSAGE
 * emoji: AUTO REACT TO MESSAGE
 * presence: AUTO UPDATE PRESENCE
 * onlyOwner: ONLY OWNER CAN USE THIS COMMAND
 * cmds: COMMANDS
 * handle: HOW WILL THIS COMMAND BE HANDLED
 */
module.exports = {
  autoRead: true,
  emoji: "👍",
  presence: "composing",
  onlyOwner: true,
  cmds: ["tags"],
  handle: async (nexsock, m) => {
    if (!m.groupMetadata) {
      await m.replyError(`*Perintah hanya bisa dijalankan dalam group.*`);
      return;
    }
    if (!m.args[0]) {
      await m.replyError(`*Pesan text dibutuhkan.*`);
      return;
    }
    await nexsock.sendMessage(m.groupMetadata.id, {
      text: m.args[0],
      mentions: m.groupMetadata.participants.map((val) => val.id),
    });
  },
};
