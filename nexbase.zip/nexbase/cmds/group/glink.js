const { isJidGroup } = require("@whiskeysockets/baileys");

/***
 * autoRead: AUTO READ MESSAGE
 * emoji: AUTO REACT TO MESSAGE
 * presence: AUTO UPDATE PRESENCE
 * onlyOwner: ONLY OWNER CAN USE THIS COMMAND
 * cmds: COMMANDS
 * handle: HOW WILL THIS COMMAND BE HANDLED
 */
module.exports = {
  autoRead: true,
  emoji: "👍",
  presence: "composing",
  onlyOwner: true,
  cmds: ["glink"],
  handle: async (nexsock, m) => {
    let info = {
      id: "-",
      subject: "-",
      subjectOwner: "-",
      participants: [],
    };
    let groupImage = "";
    if (m.groupMetadata) {
      info = m.groupMetadata;
    } else if (isJidGroup(m.args[0])) {
      info = await nexsock.groupMetadata(m.args[0]);
    } else {
      await m.replyError(
        `*Perintah hanya bisa dijalankan dalam group atau menggunakan argument group id.*\n*\`Contoh\`*: ${global.prefix}${m.cmd} 736371736471837@g.us`
      );
      return;
    }
    try {
      groupImage = await nexsock.profilePictureUrl(info.id, "image");
    } catch (err) {
      groupImage = "./media/cat.jpg";
    }
    const groupLink = m.botIsAdmin
      ? `https://chat.whatsapp.com/${await nexsock.groupInviteCode(info.id)}`
      : "Bot is not admin.";
    await nexsock.sendMessage(
      m.id,
      {
        text: groupLink,
        contextInfo: {
          isForwarded: true,
          forwardingScore: 999,
          forwardedNewsletterMessageInfo: {
            newsletterName: `${global.name}`,
            newsletterJid: "120363322845985392@newsletter",
            serverMessageId: 121,
          },
          externalAdReply: {
            containsAutoReply: true,
            mediaType: 1,
            mediaUrl: groupImage,
            renderLargerThumbnail: false,
            showAdAttribution: true,
            sourceUrl: "https://youtube.com/@bayumahadika",
            thumbnailUrl: groupImage,
            title: info.subject,
            body: m.cmd.toUpperCase(),
          },
        },
      },
      { quoted: m }
    );
  },
};
