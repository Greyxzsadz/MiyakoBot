/***
 * autoRead: AUTO READ MESSAGE
 * emoji: AUTO REACT TO MESSAGE
 * presence: AUTO UPDATE PRESENCE
 * onlyOwner: ONLY OWNER CAN USE THIS COMMAND
 * cmds: COMMANDS
 * handle: HOW WILL THIS COMMAND BE HANDLED
 */
module.exports = {
  autoRead: true,
  emoji: "👍",
  presence: "composing",
  onlyOwner: true,
  cmds: ["promote"],
  handle: async (nexsock, m) => {
    if (!m.groupMetadata) {
      await m.replyError(`*Perintah hanya bisa dijalankan dalam group.*`);
      return;
    }
    if (!m.botIsAdmin) {
      await m.replyError(`Bot is not admin.`);
      return;
    }
    if (m.isQuoted) {
      await nexsock.groupParticipantsUpdate(
        m.groupMetadata.id,
        [m.quoted.participant],
        "promote"
      );
    } else if (m.isMentioned) {
      await nexsock.groupParticipantsUpdate(
        m.groupMetadata.id,
        m.isMentioned,
        "promote"
      );
    } else {
      await m.replyError(
        `Kutip sebuah pesan atau tags member yang ingin dijadikan admin`
      );
    }
  },
};
