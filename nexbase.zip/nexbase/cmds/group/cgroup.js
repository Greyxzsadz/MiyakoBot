/***
 * autoRead: AUTO READ MESSAGE
 * emoji: AUTO REACT TO MESSAGE
 * presence: AUTO UPDATE PRESENCE
 * onlyOwner: ONLY OWNER CAN USE THIS COMMAND
 * cmds: COMMANDS
 * handle: HOW WILL THIS COMMAND BE HANDLED
 */
module.exports = {
  autoRead: true,
  emoji: "👍",
  presence: "composing",
  onlyOwner: true,
  cmds: ["cgroup"],
  handle: async (nexsock, m) =>
    await nexsock.groupCreate(m.args[0] || global.name, []),
};
