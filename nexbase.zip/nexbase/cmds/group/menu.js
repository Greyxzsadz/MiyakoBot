const fs = require("fs");
/***
 * autoRead: AUTO READ MESSAGE
 * emoji: AUTO REACT TO MESSAGE
 * presence: AUTO UPDATE PRESENCE
 * onlyOwner: ONLY OWNER CAN USE THIS COMMAND
 * cmds: COMMANDS
 * handle: HOW WILL THIS COMMAND BE HANDLED
 */
module.exports = {
  autoRead: true,
  emoji: "👍",
  presence: "composing",
  onlyOwner: false,
  cmds: ["groupmenu"],
  handle: async (nexsock, m) =>
    await nexsock.sendMessage(
      m.id,
      {
        text: `╔═══━━━─── • ───━━━═══╗
║ ◉ *\`${global.prefix}cgroup\`* -/subject
║ ╘ Create group
║ ◉ *\`${global.prefix}clone\`* inGroup/groupId
║ ╘ Clone group
║ ◉ *\`${global.prefix}ginfo\`* inGroup/groupId
║ ╘ Group info
║ ◉ *\`${global.prefix}glink\`* inGroup/groupId
║ ╘ Group link
║ ◉ *\`${global.prefix}ulink\`* inGroup/groupId
║ ╘ Update group link
║ ◉ *\`${global.prefix}close\`* inGroup
║ ╘ Close group
║ ◉ *\`${global.prefix}open\`* inGroup
║ ╘ Open group
║ ◉ *\`${global.prefix}promote\`* quoted/mention
║ ╘ Change member to admin
║ ◉ *\`${global.prefix}demote\`* quoted/mention
║ ╘ Change admin to member
║ ◉ *\`${global.prefix}kick\`* quoted/mention
║ ╘ Kick member
║ ◉ *\`${global.prefix}join\`* groupLink
║ ╘ Join group
║ ◉ *\`${global.prefix}leave\`* groupId
║ ╘ Leave group
║ ◉ *\`${global.prefix}tags\`* text
║ ╘ Tag all/Hidetag
║ ◉ *\`${global.prefix}antilink\`* inGroup
║ ╘ Anti link
╚═══━━━─── • ───━━━═══╝`,

        contextInfo: {
          isForwarded: true,
          forwardingScore: 999,
          forwardedNewsletterMessageInfo: {
            newsletterName: `${global.name}`,
            newsletterJid: "120363322845985392@newsletter",
            serverMessageId: 121,
          },
          externalAdReply: {
            containsAutoReply: true,
            mediaType: 1,
            mediaUrl: "./media/cat.jpg",
            renderLargerThumbnail: false,
            showAdAttribution: true,
            sourceUrl: "https://youtube.com/@bayumahadika",
            thumbnail: fs.readFileSync("./media/cat.jpg"),
            thumbnailUrl: "./media/cat.jpg",
            title: global.name,
            body: m.cmd.toUpperCase(),
          },
        },
      },
      { quoted: m }
    ),
};
