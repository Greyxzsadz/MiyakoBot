const { isJidGroup } = require("@whiskeysockets/baileys");
const sleep = require("@utils/sleep");

/***
 * autoRead: AUTO READ MESSAGE
 * emoji: AUTO REACT TO MESSAGE
 * presence: AUTO UPDATE PRESENCE
 * onlyOwner: ONLY OWNER CAN USE THIS COMMAND
 * cmds: COMMANDS
 * handle: HOW WILL THIS COMMAND BE HANDLED
 */
module.exports = {
  autoRead: true,
  emoji: "👍",
  presence: "composing",
  onlyOwner: true,
  cmds: ["clone"],
  handle: async (nexsock, m) => {
    let info = {
      id: "-",
      subject: "-",
      subjectOwner: "-",
      participants: [],
    };
    if (m.groupMetadata) {
      info = m.groupMetadata;
    } else if (isJidGroup(m.args[0])) {
      info = await nexsock.groupMetadata(m.args[0]);
    } else {
      await m.replyError(
        `*Perintah hanya bisa dijalankan dalam group atau menggunakan argument group id.*\n*\`Contoh\`*: ${global.prefix}${m.cmd} 736371736471837@g.us`
      );
      return;
    }
    try {
      info.groupImage = await nexsock.profilePictureUrl(info.id, "image");
    } catch (err) {
      info.groupImage = "./media/cat.jpg";
    }
    let index = 0;
    const participants = info.participants
      .map((val) => val.id)
      .filter((val) => al !== nexsock.id);
    const group = await nexsock.groupCreate(`Clone ${info.subject}`, []);
    while (index < participants.length) {
      await sleep(5000);
      await nexsock.groupParticipantsUpdate(
        group.id,
        [participants[index]],
        "add"
      );
      index++;
    }
  },
};
