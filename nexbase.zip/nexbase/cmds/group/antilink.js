/***
 * autoRead: AUTO READ MESSAGE
 * emoji: AUTO REACT TO MESSAGE
 * presence: AUTO UPDATE PRESENCE
 * onlyOwner: ONLY OWNER CAN USE THIS COMMAND
 * cmds: COMMANDS
 * handle: HOW WILL THIS COMMAND BE HANDLED
 */
module.exports = {
  autoRead: true,
  emoji: "👍",
  presence: "composing",
  onlyOwner: true,
  cmds: ["antilink"],
  handle: async (nexsock, m) => {
    if (!m.groupMetadata) {
      await m.replyError(`*Perintah hanya bisa dijalankan dalam group.*`);
      return;
    }
    if (!m.isMyGroup) {
      global.db.groups.push({
        id: m.id,
        antilink: true,
      });
    } else {
      m.isMyGroup.antilink = !m.isMyGroup.antilink;
    }
    await global.save("groups", global.db.groups);
  },
};
