const fs = require("fs");
/***
 * autoRead: AUTO READ MESSAGE
 * emoji: AUTO REACT TO MESSAGE
 * presence: AUTO UPDATE PRESENCE
 * onlyOwner: ONLY OWNER CAN USE THIS COMMAND
 * cmds: COMMANDS
 * handle: HOW WILL THIS COMMAND BE HANDLED
 */
module.exports = {
  autoRead: true,
  emoji: "👍",
  presence: "composing",
  onlyOwner: false,
  cmds: ["pushmenu"],
  handle: async (nexsock, m) =>
    nexsock.sendMessage(
      m.id,
      {
        text: global.mess.dev,
        contextInfo: {
          isForwarded: true,
          forwardingScore: 999,
          forwardedNewsletterMessageInfo: {
            newsletterName: `${global.name}`,
            newsletterJid: "120363350035853098@newsletter",
            serverMessageId: 100,
          },
          externalAdReply: {
            containsAutoReply: true,
            mediaType: 1,
            mediaUrl: "./media/push.jpg",
            renderLargerThumbnail: false,
            showAdAttribution: true,
            sourceUrl: "https://youtube.com/@bayumahadika",
            thumbnail: fs.readFileSync("./media/push.jpg"),
            thumbnailUrl: "./media/push.jpg",
            title: global.name,
            body: m.cmd.toUpperCase(),
          },
        },
      },
      { quoted: m }
    ),
};
