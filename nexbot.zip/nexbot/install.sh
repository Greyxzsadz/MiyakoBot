pkg update && pkg upgrade -y
pkg install nodejs ffmpeg git libvips python3 clang make -y
npm install --production --legacy-peer-deps
npm start
